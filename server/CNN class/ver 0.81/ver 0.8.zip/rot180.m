function out = rot180(inp)
out = rot90(rot90(inp));
end